
global.creator = "Alwaysriky - DcoderX"
global.password_admin = "alwaysriky01"
global.apikey = ["skyzo77", "alwaysriky", "alokdiskon"]